package porcelain_test

import (
	"fmt"
	"net/http"
	"os"

	"github.com/google/uuid"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/calebamiles/keps/pkg/porcelain"
)

var _ = Describe("operations against the Github API", func() {
	Describe("CreateGithubRepo()", func() {
		It("Creates a public GitHub repository", func() {
			repoName := fmt.Sprintf("keps-test-repository-%s", uuid.New().String())

			githubToken := os.Getenv("KEP_TEST_GITHUB_TOKEN")
			Expect(githubToken).ToNot(BeEmpty(), "KEP_TEST_GITHUB_TOKEN unset and required for test")

			tokenProvider := newMockTokenProvider()

			// call #1: create repo request
			tokenProvider.ValueOutput.Ret0 <- githubToken
			tokenProvider.ValueOutput.Ret1 <- nil

			// call #2: delete repo callback
			tokenProvider.ValueOutput.Ret0 <- githubToken
			tokenProvider.ValueOutput.Ret1 <- nil

			repoUrl, deleteRepo, err := porcelain.CreateGithubRepo(tokenProvider, repoName)
			Expect(err).ToNot(HaveOccurred(), "creating GitHub repo during test")

			resp, err := http.Get(repoUrl)
			Expect(err).ToNot(HaveOccurred(), "GET against created GitHub repo")
			defer resp.Body.Close()

			Expect(resp.StatusCode).To(Equal(http.StatusOK), "GET should return 200 OK")

			err = deleteRepo()
			Expect(err).ToNot(HaveOccurred(), "deleting GitHub repo after test")
		})
	})
})
